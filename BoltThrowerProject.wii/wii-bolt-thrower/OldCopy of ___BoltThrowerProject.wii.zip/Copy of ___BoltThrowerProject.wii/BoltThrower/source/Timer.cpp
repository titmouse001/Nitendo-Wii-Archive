#include <gccore.h>
#include "ogc\lwp_watchdog.h"
#include "timer.h"
#include "Util.h"

Timer::Timer()
{
	SetTimerSeconds(0);
}

bool Timer::IsTimerDone()
{
	return (Util::timer_gettime() >= GetTimerTicks() );
}

void Timer::SetTimerSeconds(u32 Seconds) 
{ 
	m_Timer = Util::timer_gettime() + secs_to_ticks(Seconds);
}

u32 Timer::GetTimerSeconds() 
{ 
	return ticks_to_secs(m_Timer - Util::timer_gettime());
}

