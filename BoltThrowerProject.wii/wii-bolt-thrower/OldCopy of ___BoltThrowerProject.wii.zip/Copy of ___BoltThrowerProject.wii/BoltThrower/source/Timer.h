#ifndef Timer_H_
#define Timer_H_

#include <gccore.h>

class Timer
{
private:
	u64 GetTimerTicks() const { return m_Timer; }

public:
	Timer();
	void SetTimerSeconds(u32 Seconds);
	bool IsTimerDone();
	u32 GetTimerSeconds();

	u64 m_Timer;
};

#endif