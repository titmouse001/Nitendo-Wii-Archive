#ifndef Intro_H
#define Intro_H

#include <vector>
#include <map>
#include "HashLabel.h"
#include "GameLogic.h"

class ImageManager;
class Vessel;

class Intro 
{

public:
	Intro();

private:
	//void Logic();

};


#endif
