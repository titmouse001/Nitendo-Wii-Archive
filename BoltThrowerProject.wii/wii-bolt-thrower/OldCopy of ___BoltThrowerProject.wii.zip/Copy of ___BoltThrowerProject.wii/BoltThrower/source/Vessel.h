#ifndef Vessel_H
#define Vessel_H

#include "GCTypes.h"
#include "Util.h"
//#include <gccore.h>
#include "ogc\lwp_watchdog.h"
#include "ogc\gu.h"
#include <string>
#include <math.h>


class  HashLabel;
class  WiiManager;

class  Item3D
{
public:
	Item3D()
	{
		m_Pos.x=0;
		m_Pos.y=0;
		m_Pos.z=0;
		m_Vel.x=0;
		m_Vel.y=0;
		m_Vel.z=0;
		m_Scale.x=1;
		m_Scale.y=1;
		m_Scale.z=1;
		m_Rotate.x=0;
		m_Rotate.y=0;
		m_Rotate.z=0;
		m_RotateAmount.x=0;
		m_RotateAmount.y=0;
		m_RotateAmount.z=0;
		m_Enable = true;
	}

	guVector& GetPos() { return m_Pos ;}
	void SetPos(f32 x,f32 y , f32 z) { m_Pos.x = x; m_Pos.y = y; m_Pos.z = z; }
	void AddPos(f32 x,f32 y , f32 z) { m_Pos.x += x; m_Pos.y += y; m_Pos.z += z; }
	f32 GetX() const { return m_Pos.x; }
	f32 GetY() const { return m_Pos.y; }
	f32 GetZ() const { return m_Pos.z; }
	
	void SetVel(guVector& v) { m_Vel  = v; }
	void SetVel(f32 x,f32 y , f32 z) { m_Vel.x = x; m_Vel.y = y; m_Vel.z = z; }
	void AddVel(f32 x,f32 y , f32 z) { m_Vel.x += x; m_Vel.y += y; m_Vel.z += z; }
	void AddVel(guVector& v) { m_Vel.x += v.x; m_Vel.y += v.y; m_Vel.z += v.z; }

	void ReduceVel(f32 fFactor) { m_Vel.x *= fFactor; m_Vel.y *= fFactor; m_Vel.z *= fFactor; }

	void SetVelX(float Val) { m_Vel.x = Val; }
	void SetVelY(float Val) { m_Vel.y = Val; }
	void SetVelZ(float Val) { m_Vel.z = Val; }
	f32 GetVelX() const { return m_Vel.x; }
	f32 GetVelY() const { return m_Vel.y; }
	f32 GetVelZ() const { return m_Vel.z; }

	guVector& GetVel() { return m_Vel; }


	void AddVelToPos() { m_Pos.x += m_Vel.x; m_Pos.y += m_Vel.y; m_Pos.z +=  m_Vel.z; }
	void AddVelToPos(float fFactor) { m_Pos.x += m_Vel.x*fFactor; m_Pos.y += m_Vel.y*fFactor; m_Pos.z += m_Vel.z*fFactor; }

	void SetRotate(f32 x, f32 y , f32 z) { m_Rotate.x = x; m_Rotate.y = y; m_Rotate.z = z; }
	void AddRotateFromAmount() { m_Rotate.x += m_RotateAmount.x; m_Rotate.y += m_RotateAmount.y; m_Rotate.z +=  m_RotateAmount.z; }
	f32 GetRotateX() const { return m_Rotate.x; }
	f32 GetRotateY() const { return m_Rotate.y; }
	f32 GetRotateZ() const { return m_Rotate.z; }

	void SetRotateAmount(f32 x, f32 y , f32 z) { m_RotateAmount.x = x; m_RotateAmount.y = y; m_RotateAmount.z = z; }
	f32 GetRotateAmountX() const { return m_RotateAmount.x; }
	f32 GetRotateAmountY() const { return m_RotateAmount.y; }
	f32 GetRotateAmountZ() const { return m_RotateAmount.z; }

	void DampRotation(float Value) { m_RotateAmount.x *= Value;	m_RotateAmount.y *= Value; m_RotateAmount.z *= Value; }

	void SetScale(f32 x, f32 y , f32 z)  { m_Scale.x = x; m_Scale.y = y; m_Scale.z = z; }
	void MulScale(float Factor)  { m_Scale.x *= Factor; m_Scale.y *= Factor; m_Scale.z *= Factor; }
	const guVector& GetScale() const { return m_Scale; }
	f32 GetScaleX() const { return m_Scale.x; }
	f32 GetScaleY() const { return m_Scale.y; }
	f32 GetScaleZ() const { return m_Scale.z; }

	bool  InsideRadius(float center_x, float center_y, float radius)
	{
		float square_dist = ((GetX()-center_x)*(GetX()-center_x) ) + ((GetY()-center_y)*(GetY()-center_y)) ;
		return ( fabs(square_dist) < (radius) );
	}
	bool  InsideRadius(Item3D& rItem, float radius)
	{
		// note: The radius param takes a squared value
		float XToCheck(rItem.GetX());
		float YToCheck(rItem.GetY());
		float square_dist = ((GetX()-XToCheck)*(GetX()-XToCheck) ) + ((GetY()-YToCheck)*(GetY()-YToCheck)) ;
		return ( fabs(square_dist) < radius );
	}

	void SetEnable(bool State) { m_Enable = State; }
	bool GetEnable() { return m_Enable; }

private:
	guVector	m_Pos;
	guVector	m_Vel;
	guVector	m_Rotate;
	guVector	m_RotateAmount;
	guVector	m_Scale;
//	std::string m_ModelName;
	bool		m_Enable;

};

class Vessel
{
public:
	Vessel() :	m_FireRate(222.0f), m_BulletSpeedFactor(0.10f), m_fTurrentDirection(0.0f),
				m_SpeedFactor(1.0f), m_iEndFrame(0), m_fFrameStart(0),m_fFrame(0), m_fFrameSpeed(0.025f), m_iShieldLevel(1), 
				m_FacingDirection(0), m_Spin(0.0f), m_Gravity(0.995f), m_iSpentValue(0), m_Alpha(255), m_bGoingBoom(false),
				m_fCurrentScaleFactor(1.0f),m_fScaleToFactor(1.0f), m_fScaleToFactorSpeed(0.20f)
	{
//		m_Pos = {0,0,0};
//		m_Vel = {0,0,0};
	}

	Vessel(guVector& Pos, guVector& Velocity, float StartFrame, float EndFrame, float FrameSpeed, float Gravity) :
				m_FireRate(222.0f), m_BulletSpeedFactor(0.10f), m_fTurrentDirection(0.0f),
				m_SpeedFactor(1.0f),
				m_iEndFrame(EndFrame), 
				m_fFrameStart(StartFrame),
				m_fFrame(StartFrame), 
				m_fFrameSpeed(FrameSpeed), 
				m_iShieldLevel(1), m_FacingDirection(0), m_Spin(0.0f), 
				m_Gravity(Gravity), 
				m_iSpentValue(0), m_Alpha(255), m_bGoingBoom(false),
				m_fCurrentScaleFactor(1.0f),m_fScaleToFactor(1.0f), m_fScaleToFactorSpeed(0.20f)
	{
		m_Pos = Pos;
		m_Vel = Velocity;
	}

	void  Init();

	void SetPos(f32 x,f32 y , f32 z);
	void SetZ(f32 z) {m_Pos.z = z;}

	void AddPos(guVector& rVector);
	void AddPos(f32 x, f32 y, f32 z);
	void AddVel(guVector& rVector);
	void AddVel(f32 x, f32 y, f32 z);
	void SetVel(f32 x, f32 y, f32 z);
	void AddVelToPos();

	void VelReduce();
	guVector& GetPos() { return m_Pos; }
	void SetPos(guVector& v ) { SetPos(v.x,v.y,v.z); }
	f32 GetX() const { return m_Pos.x; }
	f32 GetY() const { return m_Pos.y; }
	f32 GetZ() const { return m_Pos.z; }

	guVector& GetVel() { return m_Vel; }
	f32 GetVelX() const { return m_Vel.x; }
	f32 GetVelY() const { return m_Vel.y; }
	void SetVel(guVector& Vel ) { m_Vel = Vel; }
	void SetVelX(float Val) { m_Vel.x = Val; }
	void SetVelY(float Val) { m_Vel.y = Val; }

	void SetFacingDirection(float Value) { m_FacingDirection = Value; }
	void AddFacingDirection(float Value) ;
	f32 GetFacingDirection() const { return m_FacingDirection; }

	bool  InsideRadius(float center_x, float center_y, float radius);
	bool  InsideRadius(Vessel& rVessel, float radius);

	float GetSpin() const { return m_Spin; }
	void SetSpin(float fValue)  { m_Spin = fValue; }

	float GetGravity() const { return m_Gravity; }
	void SetGravity(float fValue) { m_Gravity = fValue;}

	int GetSpent() const { return m_iSpentValue; }
	void SetSpent(int iSpent) { m_iSpentValue = iSpent;}
	int ReduceSpent(int iSpent=1) { m_iSpentValue -= iSpent; return m_iSpentValue; }

	bool GetGoingBoom() const { return m_bGoingBoom; }
	void SetGoingBoom(bool bState ) { m_bGoingBoom= bState;}

	u8 GetAlpha() { return m_Alpha; }
	void SetAlpha(u8 Value) { m_Alpha = Value;}

	float GetCurrentScaleFactor()					{ return m_fCurrentScaleFactor;   }
	void  SetCurrentScaleFactor(float fValue)		{ m_fCurrentScaleFactor = fValue; }
	float GetScaleToFactor()						{ return m_fScaleToFactor;   }
	void  SetScaleToFactor(float fValue)			{ m_fScaleToFactor = fValue; }
	float AddCurrentScaleFactor(float fValue)		{ return m_fCurrentScaleFactor += fValue; }
	
	void  SetScaleToFactorSpeed(float fValue)		{ m_fScaleToFactorSpeed = fValue; }
	float GetScaleToFactorSpeed()					{ return m_fScaleToFactorSpeed; }

	float GetTurrentDirection() { return m_fTurrentDirection; }
	void SetTurrentDirection( float fValue) { m_fTurrentDirection = fValue; }
	void AddTurrentDirection(float fValue);

	int GetShieldLevel() const { return m_iShieldLevel; }
	void SetShieldLevel(int Value) { m_iShieldLevel = Value; }
	void AddShieldLevel(int Value) { m_iShieldLevel += Value; }
	bool IsShieldOk() const { return m_iShieldLevel > 0; }
	bool IsShieldFailed() const { return m_iShieldLevel <= 0; }

	float GetFrame() const { return m_fFrame; }
	void SetFrame(float Value) { m_fFrame = Value; }
	void  AddFrame(float Value) { m_fFrame+=Value; }
	void  AddFrame() { m_fFrame+=m_fFrameSpeed; }

	float GetFrameSpeed() const { return m_fFrameSpeed; }
	void SetFrameSpeed(float Value) { m_fFrameSpeed = Value; }

	int GetEndFrame() const { return m_iEndFrame; }
	void SetEndFrame(int Value) { m_iEndFrame = Value; }


	float GetFrameStart() const { return m_fFrameStart; }
	void SetFrameStart(float Value) { m_fFrameStart = Value; }

	int GetFireRate() const { return m_FireRate; }
	void SetFireRate(int Value) { m_FireRate = Value; }

	float GetBulletSpeedFactor() const { return m_BulletSpeedFactor; }
	void SetBulletSpeedFactor(float Value) { m_BulletSpeedFactor = Value; }

	float GetSpeedFactor() const { return m_SpeedFactor; }
	void SetSpeedFactor(float Value) { m_SpeedFactor = Value; }


	void DetonationSpin();
	void SetFrameGroupWithRandomFrame(HashLabel FrameName, float FrameSpeed);
	void SetFrameGroup(HashLabel FrameName, float FrameSpeed=0);
	
	
private:

	// gun ship section
	int			m_FireRate;
	float		m_BulletSpeedFactor;
	float		m_fTurrentDirection;

	// factor for movement speed
	float		m_SpeedFactor;

	int			m_iEndFrame;
	float		m_fFrameStart;
	float		m_fFrame;
	float		m_fFrameSpeed;
	int			m_iShieldLevel;

	guVector	m_Pos;
	guVector	m_Vel;
	float		m_FacingDirection;
	float		m_Spin;
	float		m_Gravity;
	int			m_iSpentValue;
	u8			m_Alpha;  
	bool		m_bGoingBoom;

	//explosions
	float		m_fCurrentScaleFactor; 
	float		m_fScaleToFactor;
	float		m_fScaleToFactorSpeed;
};


class PlayerVessel : public Vessel
{
public:
	PlayerVessel() : m_PickUpTotal(0.0f) {;}
	void AddToPickUpTotal(int Value) { m_PickUpTotal += Value; }
	int GetPickUpTotal() { return m_PickUpTotal; }
	void ClearPickUpTotal() { m_PickUpTotal=0.0f; }
private:
	int m_PickUpTotal;
};


class  Item3DChronometry : public Item3D
{
public:
	void SetCountdownSeconds(u32 Value)	{ m_Timer = Util::timer_gettime() + secs_to_ticks(Value) ;}
	bool IsCountdownFinished()	{return Util::timer_gettime() > m_Timer;}

private:
	u64 m_Timer;
};

#endif
