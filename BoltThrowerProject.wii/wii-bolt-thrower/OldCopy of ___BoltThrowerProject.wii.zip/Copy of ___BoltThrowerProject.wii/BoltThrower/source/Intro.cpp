#include "GameLogic.h"

#include <gccore.h>
#include <math.h>

#include "Singleton.h"
#include "WiiManager.h"
#include "Image.h"
#include "ImageManager.h"
#include "InputDeviceManager.h"
#include "FontManager.h"
#include "SoundManager.h"
#include "Vessel.h"
#include "render3D.h"
#include "Util.h"
#include "Util3D.h"
#include "debug.h"
#include "HashString.h"

#include "Intro.h"

Intro::Intro()
{
}
//
//
//void Intro::Logic()
//{
//
//	WiiManager& Wii( Singleton<WiiManager>::GetInstanceByRef() );
//	WPAD_ScanPads();
//
//	Wii.GetInputDeviceManager()->Store();
//	Vtx* WiiMote( Wii.GetInputDeviceManager()->GetIRPosition() );
//
//
//	static float bbb(0);
//	Wii.m_pSpaceBackground->DrawImageXYZ(0,0, 9400,255,bbb*0.05,15.0f );
//
//
//	{
//		static float fff(0);
//		fff+=0.01;
//		GetPlrVessel()->SetPos((sin(fff)*200),-100,0);  // something for bad ships to lock onto
//	}
//
//
//	bbb+=0.005f;
//
//	//-------------------
//	GX_SetZMode(GX_TRUE, GX_LEQUAL, GX_TRUE);
//	Wii.GetCamera()->SetLightOn2();
//	//--------------------------
//	Mtx Model,mat;
//	//--------------------------
//	guMtxRotRad(Model,'y', bbb) ;
//	guMtxScaleApply(Model,Model,58,58,58);
//	guMtxTrans(mat, 0,100, 0);
//	guMtxConcat(mat,Model,Model);
//	guMtxConcat(Wii.GetCamera()->GetcameraMatrix(),Model,Model);
//	Wii.Render.RenderModel("MoonHiRess", Model);
//	//--------------------------
//
//#define INTRO_AMOUNTROCKS (320)
//	static float scale[INTRO_AMOUNTROCKS];
//	static float Rot[INTRO_AMOUNTROCKS];
//	float Gap;
//	static float SpinSpeed[INTRO_AMOUNTROCKS];
//	static int once=1;
//	if (once || IsProbeMineContainerEmpty())
//	{
//		ClearProbeMineContainer();
//		for (std::vector<Vessel>::iterator BadIter(m_BadContainer->begin()); BadIter!=m_BadContainer->end(); ++BadIter)
//		{
//			BadIter->m_iShieldLevel =0;
//		}
//
//		if (once)
//		{
//			Gap = ((M_PI) / (float)INTRO_AMOUNTROCKS  );
//			for (int i=0;i<INTRO_AMOUNTROCKS;i++)
//			{
//				scale[i]=((rand()%1200)*0.01)+1.5f;
//				Rot[i] = (rand()%314)*0.01;
//				SpinSpeed[i] = 0.001+ ((rand()%100)*0.000025);
//			}
//			once=0;
//		}
//
//
//		Vessel ProbeMine;
//		Tga::PIXEL* pData = (Tga::PIXEL*)Wii.m_pTinyLogo;
//
//		for (u16 y(0); y<Wii.m_pTinyLogoHeader.height; ++y)
//		{
//			for (u16 x(0); x<Wii.m_pTinyLogoHeader.width; ++x)
//			{
//				Tga::PIXEL Value = pData[x + (y*Wii.m_pTinyLogoHeader.width)];
//				if (Value.b!=0)
//					continue;
//
//				ProbeMine.SetPos(x*9-240,y*9-300,0); 
//
//				ProbeMine.m_fFrameStart = m_FrameEndStartConstainer[HashString::ProbeMineFrames].StartFrame;
//				ProbeMine.m_iEndFrame = m_FrameEndStartConstainer[HashString::ProbeMineFrames].EndFrame;
//				ProbeMine.m_fFrame = ProbeMine.m_fFrameStart ;
//				ProbeMine.SetGravity(0.985f);
//				ProbeMine.SetVel( 0, 1.15f, 0);
//				m_ProbeMineContainer->push_back(ProbeMine);
//			}
//		}
//	}
//
//	if ((int)m_BadContainer->size() <= Wii.GetXmlVariable(HashString::AmountBadShips)/2 )
//	{
//		for (int i=0; i< Wii.GetXmlVariable(HashString::AmountBadShips); ++i)
//			AddBadShip(300-(rand()%600),255,1);
//	}
//
//	Wii.Render.RenderModelPreStage("Rock1");  // rock1 & rock2 use the same texture
//
//	float aaa=bbb;
//	for (int i=0;i<INTRO_AMOUNTROCKS;i++)
//	{
//		guMtxRotRad(Model,'y', Rot[i]*8) ;
//		guMtxRotRad(mat,'z', Rot[i]*4) ;
//		guMtxConcat(mat,Model,Model);
//
//		guMtxScaleApply(Model,Model,scale[i],scale[i],scale[i]);
//
//		guMtxTrans(mat, 140 + scale[i]*12,100, 0);
//		guMtxConcat(mat,Model,Model);
//
//		guMtxRotRad(mat,'y', aaa*2) ;
//		guMtxConcat(mat,Model,Model);
//
//		guMtxConcat(Wii.GetCamera()->GetcameraMatrix(),Model,Model);
//
//		if (scale[i]>8)
//			Wii.Render.RenderModelMinimal("Rock1", Model);
//		else
//			Wii.Render.RenderModelMinimal("Rock2", Model);
//
//		aaa+=Gap;
//		Rot[i]+=SpinSpeed[i];
//	}
//	//------------------------
//	Wii.GetCamera()->SetLightOff();
//
//	GX_SetZMode (GX_FALSE, GX_LEQUAL, GX_FALSE);
//
//	BadShips();
//	FeoShieldLevelLogic();
//	ExplosionLogic();
//
//	if (m_ProbeMineContainer->size() < 75)
//		ProbeMineLogic(0.0450f,380.0f);
//	else
//		ProbeMineLogic(0.007f,555.0f);
//
//	DisplayBadShips();
//	DisplayProbMines();
//	DisplayExplosions();
//
//
//	{
//		static float wobble	(0);
//		wobble+=0.05;
//		Wii.Printf(-210, 95 + exp((sin(wobble)*2.8f)),"PRESS A TO CONTINUE");
//	}
//
//	if (WiiMote!=NULL)
//	{
//		Wii.m_pCursor->DrawImageXY(	
//			Wii.GetCamera()->GetCamX() + WiiMote->x - (Wii.GetScreenWidth()/2), 
//			Wii.GetCamera()->GetCamY() + WiiMote->y - (Wii.GetScreenHeight()/2));
//	}
//
//	//Wii.GetMenuManager()->Draw();
//	//Wii.GetMenuManager()->MenuLogic();
//
//	GX_SetZMode (GX_TRUE, GX_LEQUAL, GX_TRUE);
//
//	Wii.SwapScreen();  // to clear zbuffer keep GX_SetZMode on until after this call 
//	GX_SetZMode (GX_FALSE, GX_LEQUAL, GX_FALSE);
//}
