#include "sys_state.h"

u32 _sys_state_curr;
