#ifndef __GECKOUSB_H___
#define __GECKOUSB_H___

#include "debug_if.h"

struct dbginterface* usb_init(s32 channel);

#endif
